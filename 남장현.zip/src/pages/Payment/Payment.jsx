import React from "react";

function PayMent() {
  return <div>PayMent</div>;
}

export default PayMent;
