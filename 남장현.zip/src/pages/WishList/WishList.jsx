import React from "react";

function WIshList() {
  return <div>WIshList</div>;
}

export default WIshList;
