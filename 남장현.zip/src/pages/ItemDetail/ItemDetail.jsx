import React from "react";

function ItemDetail() {
  return <div>ItemDetail</div>;
}

export default ItemDetail;
